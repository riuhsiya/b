game="$(pm list packages -3|cut -f2 -d:|grep "$(cat /sdcard/SK/GameList/game.txt)")"
systemui="$(pm list packages|cut -f2 -d:|grep systemui)"
echo "
░██████╗░░░░░░██╗░░██╗
██╔════╝░░░░░░██║░██╔╝
╚█████╗░█████╗█████═╝░
░╚═══██╗╚════╝██╔═██╗░
██████╔╝░░░░░░██║░╚██╗
╚═════╝░░░░░░░╚═╝░░╚═╝
@SukitooV1"
echo ""
sleep 0.8
echo "──────── ⋆⋅Infomartion⋅⋆ ────────"
sleep 1
echo " Developer     : SukitooV1"
echo " Thanks To     : Azazilexe & Noiz"
echo " Version       : 1.1"
echo " Module        : Performance | Stable"
sleep 1
echo "──────── ⋆⋅Device⋅⋆ ────────"
sleep 0.5
echo " Kernel             : $(uname -r)"
echo " Android Version    : $(getprop ro.build.version.release)"
sleep 0.5
echo " Device Model       : $(getprop ro.product.model)"
echo " Brand              : $(getprop ro.product.brand)"
sleep 0.5
echo " GPU                : $(getprop ro.hardware.egl)"
echo " CPU                : $(getprop ro.product.cpu.abi)"
sleep 0.5
echo "──────── ⋆⋅Proccesing⋅⋆ ────────"
sleep 1
echo "[!] Procces Installing..."
echo ""
sleep 0.8
function tweaks {
  for a in $game;do am send-trim-memory "$a" RUNNING_CRITICAL;done
      am memory-factor set CRITICAL
      cmd looper_stats disable
      cmd power set-adaptive-power-saver-enabled false
      cmd power set-fixed-performance-mode-enabled true
      cmd power set-mode 0
      cmd thermalservice override-status 0
      pm log-visibility --disable "$a"
      dumpsys deviceidle whitelist +"$a"
      cmd app_hibernation set-state --global "$a" false
      am set-standby-bucket "$a" 10
      am set-bg-restriction-level "$a" unrestricted
      dumpsys deviceidle enable
      dumpsys deviceidle force-idle
      dumpsys deviceidle step deep
      sm defragment abort
      sm idle-maint abort
      simpleperf --log fatal --log-to-android-buffer 0
      pm trim-caches 999G
      settings put system POWER_PERFORMANCE_MODE_OPEN 1
      settings put system POWER_SAVE_MODE_OPEN 0
  for b in $game;do
      am set-standby-bucket "$b" active
  done
  #driver
  c="$(for c in $game $systemui;do printf "$c",;done)"
      settings put global angle_gl_driver_all_angle 3
      settings put global angle_gl_driver_selection_pkgs "$c"
      settings put global game_driver_all_apps 3
      settings put global game_driver_opt_in_apps "$c"
      settings put global updatable_driver_all_apps 3
      settings put global updatable_driver_production_opt_in_apps "$c"
  ####End
  for c in $(seq 0 32 1024);do
      logcat -G "$c"m
  done
}> dev/null 2>&1
function prop {
  setprop debug.stagefright.renderengine.backend skiaglthreaded
  setprop debug.renderengine.backend skiaglthreaded
  setprop debug.hwui.renderer skiagl
  setprop debug.xr.graphicsPlugin SkiaGL
  setprop debug.performance.tuning 1 
  setprop debug.hwui.capture_skp_enabled 0
  setprop debug.hwui.bit_hdr_headroom 0
  setprop debug.hwui.skia_use_perfetto_track_events 0
  setprop debug.hwui.drawing_enabled 1
  setprop debug.hwui.use_buffer_age true
  setprop debug.hwui.target_cpu_time_percent 5
  setprop debug.hwui.filter_test_overhead 0
  setprop debug.hwui.memory_dump_disable 1
  setprop debug.hwui.skp_filename false
  setprop debug.hwui.capture_skp_frames 0
  setprop debug.hwui.skia_tracing_enabled 0
  setprop debug.hwui.enable_compile_accelerate true
  setprop debug.sf.disable_backpressure 1
  setprop debug.sf.high_fps_early_gl_phase_offset_ns -5000000
  setprop debug.sf.high_fps_early_phase_offset_ns -5000000
  setprop debug.sf.high_fps_late_app_phase_offset_ns 1000000
  setprop debug.sf.high_fps_late_sf_phase_offset_ns -5000000
  setprop debug.sf.enable_hwc_vds 0
  setprop debug.sf.latch_unsignaled 1
  setprop debug.sf.phase_offset_threshold_for_next_vsync_ns 1000000
  setprop debug.vulkan.layers VK_KHR_dynamic_rendering,VK_KHR_synchronization2,VkFramebuffer;
  setprop debug.composition.type gpu
  setprop debug.OVRPlugin.systemDisplayFrequency 120
  setprop debug.OVRManager.cpuLevel 3
  setprop debug.OVRManager.gpuLevel 3
}
function cache {
  cmd stats clear-puller-cache
  am clear-watch-heap -a
  
 (for cache in $(find /sdcard/ -name .thumbnails;find /sdcard/ -name *.log);do rm -rf $cache;done;pm trim-caches 999G)>/dev/null 2>&1&
 
 (for cache in $(find /sdcard/Android/Media -name .Shared;find /sdcard/Android/Media -name .StickerThumbs);do rm -rf $cache;done)>/dev/null 2>&1&
 
}>/dev/null 2>&1
function gimik {
  #Credtis : Azazilexe
  for device_config in $(cmd device_config list | cut -f 1 -d =); do
a=${device_config%/*}
b=${device_config#*/}
device_config delete $a $b
sleep 0.01
done
  for gmk in $(settings list global | grep -F "ro." | cut -F 1 -d "="; settings list secure | grep -F "ro." | cut -F 1 -d "="; settings list system | grep -F "ro." | cut -F 1 -d "="); do
settings delete global $gmk
settings delete secure $gmk
settings delete system $gmk
done

  for gmk in $(settings list global | grep -F "kernel" | cut -F 1 -d "="; settings list secure | grep -F "kernel" | cut -F 1 -d "="; settings list system | grep -F "kernel" | cut -F 1 -d "="); do
settings delete global $gmk
settings delete secure $gmk
settings delete system $gmk
done

  for gmk in $(settings list global | grep -F "vendor" | cut -F 1 -d "="; settings list secure | grep -F "vendor" | cut -F 1 -d "="; settings list system | grep -F "vendor" | cut -F 1 -d "="); do
settings delete global $gmk
settings delete secure $gmk
settings delete system $gmk
done

  for gmk in $(settings list global | grep -F "debug" | cut -F 1 -d "="; settings list secure | grep -F "debug" | cut -F 1 -d "="; settings list system | grep -F "debug" | cut -F 1 -d "="); do
settings delete global $gmk
settings delete secure $gmk
settings delete system $gmk
done
}> dev/null 2>&1
echo "[*] Installing Performance Mode"
sleep 0.8
echo "[*] Installing Game Drivers"
tweaks
echo "[*] Installing Tweaks"
prop
echo "[*] Clear Phone Cache"
cache
echo "[*] Clear String Useless"
gimik
sleep 1.5
echo ""
echo "[!] Installed Successfully..."
echo ""
sleep 1
cmd notification post -S bigtext -t 'S-K' 'Tag' 'Status : Actived ' > /dev/null 2>&1