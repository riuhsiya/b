game="
com.miHoYo.GenshinImpact
com.mobile.legends
com.roblox.client
com.dts.freefireth
com.dts.freefiremax
com.netease.newspike
"
echo "
░██████╗░░░░░░██╗░░██╗
██╔════╝░░░░░░██║░██╔╝
╚█████╗░█████╗█████═╝░
░╚═══██╗╚════╝██╔═██╗░
██████╔╝░░░░░░██║░╚██╗
╚═════╝░░░░░░░╚═╝░░╚═╝"
echo ""
sleep 1.5
echo "──────── ⋆⋅Infomartion⋅⋆ ────────"
sleep 2
echo " Developer     : SukitooV1"
echi " Thanks To     : Azazilexe & Noiz"
echo " Version       : 1.0"
echo " Module        : Performance"
sleep 1.5
echo "──────── ⋆⋅Device⋅⋆ ────────"
sleep 1
echo " Kernel             : $(uname -r)"
echo " Android SDK        : $(getprop ro.build.version.sdk)"
echo " Android Version    : $(getprop ro.build.version.release)"
echo " Device Model       : $(getprop ro.product.model)"
echo " Brand              : $(getprop ro.product.brand)"
echo " Model              : $(getprop ro.product.model)"
echo " GPU                : $(getprop ro.opengles.version)"
echo " CPU                : $(getprop ro.product.cpu.abi)"
sleep 2
echo "──────── ⋆⋅Proccesing⋅⋆ ────────"
sleep 1.5
echo "[>] Procces UnInstalling..."
function tweaks {
  for a in $game;do am send-trim-memory $a COMPLETE;done
      am memory-factor set LOW
      cmd looper_stats disable
      cmd power set-adaptive-power-saver-enabled true
      cmd power set-fixed-performance-mode-enabled false
      cmd power set-mode 1
      cmd thermalservice override-status 6
      dumpsys deviceidle enable
      dumpsys deviceidle force-idle
      dumpsys deviceidle step deep
      settings put system POWER_PERFORMANCE_MODE_OPEN 0
      settings put system POWER_SAVE_MODE_OPEN 1
      logcat -G 64k
      sm idle-maint run
      sm defragment run
      simpleperf --log fatal --log-to-android-buffer 0
  done
  for b in $(pm list packages|cut -f2 -d:);do
      pm log-visibility --disable "$b"
      dumpsys deviceidle whitelist -"$b"
      cmd sensorservice set-uid-state "$b" idle
      cmd jobscheduler cancel "$b"
      cmd app_hibernation set-state --global "$b" true
      am set-standby-bucket "$b" 50
      am set-ignore-delivery-group-policy "$b"
      am set-bg-restriction-level "$b" hibernation
      am service-restart-backoff disable "$b"
      am make-uid-idle "$b"
  done
  for c in $(settings list global|cut -f1 -d=|grep driver);do
      settings delete global "$c"
  done
}
function gimik {
  #Credtis : Azazilexe
  for device_config in $(cmd device_config list | cut -f 1 -d =); do
a=${device_config%/*}
b=${device_config#*/}
device_config delete $a $b
sleep 0.01
done

  for gmk in $(settings list global | grep -F "ro." | cut -F 1 -d "="; settings list secure | grep -F "ro." | cut -F 1 -d "="; settings list system | grep -F "ro." | cut -F 1 -d "="); do
settings delete global $gmk
settings delete secure $gmk
settings delete system $gmk
done

  for gmk in $(settings list global | grep -F "kernel" | cut -F 1 -d "="; settings list secure | grep -F "kernel" | cut -F 1 -d "="; settings list system | grep -F "kernel" | cut -F 1 -d "="); do
settings delete global $gmk
settings delete secure $gmk
settings delete system $gmk
done

  for gmk in $(settings list global | grep -F "vendor" | cut -F 1 -d "="; settings list secure | grep -F "vendor" | cut -F 1 -d "="; settings list system | grep -F "vendor" | cut -F 1 -d "="); do
settings delete global $gmk
settings delete secure $gmk
settings delete system $gmk
done

  for gmk in $(settings list global | grep -F "debug" | cut -F 1 -d "="; settings list secure | grep -F "debug" | cut -F 1 -d "="; settings list system | grep -F "debug" | cut -F 1 -d "="); do
settings delete global $gmk
settings delete secure $gmk
settings delete system $gmk
done

}> dev/null 2>&1
tweaks
gimik
echo ""
echo "[>] UnInstalled Successfully..."
sleep 1
cmd notification post -S bigtext -t 'S-K' 'Tag' 'Status : UnActived ' > /dev/null 2>&1