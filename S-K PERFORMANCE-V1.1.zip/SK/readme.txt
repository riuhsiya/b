COMMAND INSTALL S-K PERFORMANCE

INSTALL : sh /sdcard/SK/run.sh
UNINSTALL : sh /sdcard/SK/run.sh

@SukitooV1